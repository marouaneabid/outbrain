//
//  OBContent.h
//  OutbrainSDK
//
//  Created by Oded Regev on 12/10/13.
//  Copyright (c) 2017 Outbrain. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 *  This is an object container that all Outbrain objects
 *  will inherit from.
 **/

@interface OBContent : NSObject

@property (nonatomic, copy, readonly) NSDictionary *originalOBPayload;

@end
